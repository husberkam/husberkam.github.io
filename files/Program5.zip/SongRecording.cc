// Copyrights @2025 Huseyin Berat Kamer
// Implementing SongRecording functions

#include "SongRecording.h"

namespace csce240_programming_assignment_5 {

ostream& operator << (ostream& where, const SongRecording& s) {
  where << s.title_ << " (" << s.track_length_ << "s)";
  where << " Artists: ";
  for (int i = 0; i < s.num_artists_ - 1; ++i)
    where << s.artists_[i] << ", ";
  where << s.artists_[s.num_artists_ - 1];
  return where;
}

void SongRecording::Print() const {
  cout << *this << endl;
}

void SongRecording::SetTitle(string t) {
  if (t != "")
    title_ = t;
}

void SongRecording::SetTrackLength(int seconds) {
  if (seconds >= 0)
    track_length_ = seconds;
}

SongRecording::SongRecording(string title,
                             string primary_artist,
                             int track_length,
                             int num_artists)
    : title_("untitled"),
      artists_(nullptr),
      num_artists_(1),
      track_length_(0) {
  SetTitle(title);
  SetTrackLength(track_length);

  // needs to be >= 1 artist
  if (num_artists < 1) num_artists = 1;
  num_artists_ = num_artists;
  artists_ = new string[num_artists_];
  artists_[0] = (primary_artist != "" ? primary_artist : string("unknown"));
  for (int i = 1; i < num_artists_; ++i)
    artists_[i] = "unknown";
}

SongRecording::SongRecording(const SongRecording& tocopy)
    : title_(tocopy.title_),
      artists_(nullptr),
      num_artists_(tocopy.num_artists_),
      track_length_(tocopy.track_length_) {
  artists_ = new string[num_artists_];
  for (int i = 0; i < num_artists_; ++i)
    artists_[i] = tocopy.artists_[i];
}

SongRecording& SongRecording::operator = (const SongRecording& rhs) {
  if (this == &rhs) return *this;
  title_ = rhs.title_;
  track_length_ = rhs.track_length_;
  delete [] artists_;
  num_artists_ = rhs.num_artists_;
  artists_ = new string[num_artists_];
  for (int i = 0; i < num_artists_; ++i)
    artists_[i] = rhs.artists_[i];
  return *this;
}

SongRecording::~SongRecording() {
  delete [] artists_;
}

void SongRecording::SetNumArtists(int num) {
  if (num < 1) return;  // must stay >= 1
  // allocate new array,, copy and "unknown"
  string* arr = new string[num];
  int copy_count = (num < num_artists_) ? num : num_artists_;
  for (int i = 0; i < copy_count; ++i) arr[i] = artists_[i];
  for (int i = copy_count; i < num; ++i) arr[i] = "unknown";
  delete [] artists_;
  artists_ = arr;
  num_artists_ = num;
}

void SongRecording::SetArtist(string name, int which) {
  if (name == "") return;
  if (which >= 1 && which <= num_artists_)
    artists_[which - 1] = name;
}

string SongRecording::GetArtist(int which) const {
  if (which >= 1 && which <= num_artists_)
    return artists_[which - 1];
  return "out of bounds";
}

} // namespace csce240_programming_assignment_5

