// Copyright @2025 Huseyin Berat Kamer
// CSCE240 Programming Assignment 5
// Defining a SongRecording class

#ifndef SONGRECORDING_H_
#define SONGRECORDING_H_

#include<string>
using std::string;
#include<iostream>
using std::ostream;
using std::cout;
using std::endl;

namespace csce240_programming_assignment_5 {

class SongRecording {
  friend ostream& operator << (ostream&, const SongRecording&);

 public:
  // constructor with defaults
  explicit SongRecording(string title = "untitled",
                         string primary_artist = "unknown",
                         int track_length = 0,
                         int num_artists = 1);

  SongRecording(const SongRecording& tocopy);
  SongRecording& operator = (const SongRecording& rhs);
  virtual ~SongRecording();

  // getters and setters
  string GetTitle() const { return title_; }
  void SetTitle(string t);

  int GetTrackLength() const { return track_length_; }
  void SetTrackLength(int seconds);

  int GetNumArtists() const { return num_artists_; }
  void SetNumArtists(int num);

  void SetArtist(string name, int which = 1);
  // returns 'out of bounds' if invalid
  string GetArtist(int which = 1) const;

  virtual void Print() const;

 private:
  string title_;
  string* artists_;
  int num_artists_;    // >= 1
  int track_length_;   // >= 0
};

}  // namespace csce240_programming_assignment_5

#endif  // SONGRECORDING_H_
