// Copyright @2025 HuseyinBerat Kamer
// Defining a StreamingTrack derived from SongRecording

#ifndef STREAMINGTRACK_H_
#define STREAMINGTRACK_H_

#include<string>
using std::string;
#include<iostream>
using std::ostream;
using std::cout;
using std::endl;

#include "SongRecording.h"

namespace csce240_programming_assignment_5 {

class StreamingTrack : public SongRecording {
  friend ostream& operator << (ostream&, const StreamingTrack&);

 public:
  explicit StreamingTrack(string title = "untitled",
                          string primary_artist = "unknown",
                          int track_length = 0,
                          int num_artists = 1,
                          string primary_genre = "pop",
                          int streams = 0);

  // explicit
  explicit StreamingTrack(const SongRecording& base,
                          string primary_genre = "pop",
                          int streams = 0);
  // 3
  StreamingTrack(const StreamingTrack& tocopy);
  StreamingTrack& operator = (const StreamingTrack& rhs);
  ~StreamingTrack();

  // streams
  int GetStreams() const { return streams_; }
  void SetStreams(int s);          // non-negative
  void AddStreams(int delta);      // non-negative

  // genres
  int GetNumGenres() const { return num_genres_; }
  string GetGenre(int which = 1) const;  // out of bounds if invalid
  bool IsGenre(string g) const;
  void AddGenre(string g);               // add if not present
  void RemoveGenre(string g);            // remove if present

  void Print() const;

 private:
  int streams_;     // non-negative
  string* genres_;
  int num_genres_;  // non-negative
};

}  // namespace csce240_programming_assignment_5

#endif  // STREAMINGTRACK_H_

