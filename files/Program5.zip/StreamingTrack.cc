// Copyright @2025 Huseyin Berat Kamer
// Implemenying StreamingTrack functions

#include "StreamingTrack.h"

namespace csce240_programming_assignment_5 {

ostream& operator << (ostream& where, const StreamingTrack& st) {
  where << static_cast<const SongRecording&>(st);
  if (st.num_genres_ > 0) {
    where << " Genres: ";
    for (int i = 0; i < st.num_genres_ - 1; ++i)
      where << st.genres_[i] << ", ";
    where << st.genres_[st.num_genres_ - 1];
  }
  where << " Streams: " << st.streams_;
  return where;
}

void StreamingTrack::Print() const {
  cout << *this << endl;
}

StreamingTrack::StreamingTrack(string title,
                               string primary_artist,
                               int track_length,
                               int num_artists,
                               string primary_genre,
                               int streams)
    : SongRecording(title, primary_artist, track_length, num_artists),
      streams_(0),
      genres_(nullptr),
      num_genres_(0) {
  SetStreams(streams);
  num_genres_ = 1;
  genres_ = new string[1];
  genres_[0] = (primary_genre != "" ? primary_genre : string("pop"));
}

StreamingTrack::StreamingTrack(const SongRecording& base,
                               string primary_genre,
                               int streams)
    : SongRecording(base),
      streams_(0),
      genres_(nullptr),
      num_genres_(0) {
  SetStreams(streams);
  num_genres_ = 1;
  genres_ = new string[1];
  genres_[0] = (primary_genre != "" ? primary_genre : string("pop"));
}

StreamingTrack::StreamingTrack(const StreamingTrack& tocopy)
    : SongRecording(tocopy),
      streams_(tocopy.streams_),
      genres_(nullptr),
      num_genres_(tocopy.num_genres_) {
  if (num_genres_ > 0) {
    genres_ = new string[num_genres_];
    for (int i = 0; i < num_genres_; ++i)
      genres_[i] = tocopy.genres_[i];
  }
}

StreamingTrack& StreamingTrack::operator = (const StreamingTrack& rhs) {
  if (this == &rhs) return *this;
  SongRecording::operator=(rhs);
  streams_ = rhs.streams_;
  delete [] genres_;
  num_genres_ = rhs.num_genres_;
  genres_ = (num_genres_ > 0) ? new string[num_genres_] : nullptr;
  for (int i = 0; i < num_genres_; ++i)
    genres_[i] = rhs.genres_[i];
  return *this;
}

StreamingTrack::~StreamingTrack() {
  delete [] genres_;
}

void StreamingTrack::SetStreams(int s) {
  if (s >= 0)
    streams_ = s;
}

void StreamingTrack::AddStreams(int delta) {
  if (delta >= 0)
    streams_ += delta;
}

string StreamingTrack::GetGenre(int which) const {
  if (which >= 1 && which <= num_genres_)
    return genres_[which - 1];
  return "out of bounds";
}

bool StreamingTrack::IsGenre(string g) const {
  for (int i = 0; i < num_genres_; ++i)
    if (genres_[i] == g) return true;
  return false;
}

void StreamingTrack::AddGenre(string g) {
  if (g == "" || IsGenre(g)) return;
  string* arr = new string[num_genres_ + 1];
  for (int i = 0; i < num_genres_; ++i)
    arr[i] = genres_[i];
  arr[num_genres_] = g;
  delete [] genres_;
  genres_ = arr;
  ++num_genres_;
}

void StreamingTrack::RemoveGenre(string g) {
  if (!IsGenre(g)) return;
  int keep = 0;
  for (int i = 0; i < num_genres_; ++i)
    if (genres_[i] != g) ++keep;

  string* arr = (keep > 0) ? new string[keep] : nullptr;
  int idx = 0;
  for (int i = 0; i < num_genres_; ++i)
    if (genres_[i] != g) arr[idx++] = genres_[i];

  delete [] genres_;
  genres_ = arr;
  num_genres_ = keep;
}

}  // namespace csce240_programming_assignment_5
